<?php
	$host = 'localhost';
	$user = 'root';
	$pass = '';
	$db = 'projekt';

	$con = mysqli_connect($host,$user,$pass,$db);

	/* sql dotazy
		include "db.php";
		$sql = "SELECT * FROM `ahoj`";
		$query = mysqli_query($con, $sql);
		$row = mysqli_fetch_all($query);
		print_r($row);
	*/
?>